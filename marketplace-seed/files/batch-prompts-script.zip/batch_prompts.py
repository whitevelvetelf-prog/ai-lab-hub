#!/usr/bin/env python3
"""Пакетний прогін промптів із CSV.

Вхід:  CSV із колонками id,prompt
Вихід: CSV із колонками id,prompt,response,status,error

Скрипт не залежить від провайдера: реалізуйте функцію call_model().
Режим --dry-run повертає заглушку й не робить жодних запитів.
Повторний запуск пропускає рядки, які вже оброблені успішно (resume).

Приклад:
    python batch_prompts.py example_prompts.csv -o results.csv --dry-run
"""
import argparse
import csv
import os
import sys
import tempfile
import time
from pathlib import Path

FIELDS = ["id", "prompt", "response", "status", "error"]


def call_model(prompt: str) -> str:
    """ВСТАВТЕ СВІЙ ВИКЛИК МОДЕЛІ ТУТ.

    Структура (псевдокод):
        api_key = os.environ["MODEL_API_KEY"]   # ключ беріть зі змінної середовища,
                                                # не записуйте його в код
        text = <виклик SDK вашого провайдера>(prompt, timeout=60)
        return text

    Функція має повернути рядок з відповіддю або викликати виняток.
    """
    raise NotImplementedError(
        "Реалізуйте call_model() для вашого провайдера або запустіть з --dry-run"
    )


def dry_run_model(prompt: str) -> str:
    return "[DRY-RUN] " + prompt[:60]


def read_input(path: Path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        names = reader.fieldnames or []
        if "id" not in names or "prompt" not in names:
            raise SystemExit("Вхідний CSV має містити колонки id і prompt")
        rows = [r for r in reader if (r.get("prompt") or "").strip()]
    ids = [r["id"] for r in rows]
    if len(ids) != len(set(ids)):
        raise SystemExit("Значення id мають бути унікальними")
    return rows


def read_previous(path: Path):
    previous = {}
    if path.exists():
        with path.open(newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                if row.get("id"):
                    previous[row["id"]] = row
    return previous


def save(path: Path, results: dict, order: list):
    """Атомарний запис: спершу тимчасовий файл, потім заміна."""
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    with os.fdopen(fd, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for rid in order:
            if rid in results:
                writer.writerow(results[rid])
    os.replace(tmp, path)


def ask(model, prompt: str, retries: int, delay: float):
    """Повертає (відповідь, помилка). Повторює спроби з наростаючою паузою."""
    error = ""
    for attempt in range(retries + 1):
        try:
            return model(prompt), ""
        except NotImplementedError as exc:
            return "", str(exc)  # повторювати немає сенсу
        except Exception as exc:  # noqa: BLE001
            error = f"{type(exc).__name__}: {exc}"
            if attempt < retries:
                time.sleep(delay * (2 ** attempt))
    return "", error


def run(args) -> int:
    model = dry_run_model if args.dry_run else call_model
    rows = read_input(args.input)
    order = [r["id"] for r in rows]
    previous = read_previous(args.output)
    results = {}
    failed = 0

    for r in rows:
        rid, prompt = r["id"], r["prompt"]
        old = previous.get(rid)
        if old and old.get("status") == "ok" and old.get("prompt") == prompt:
            results[rid] = old
            print(f"[{rid}] пропущено (вже оброблено)")
            continue

        response, error = ask(model, prompt, args.retries, args.delay)
        status = "ok" if not error else "error"
        if error:
            failed += 1
        results[rid] = {
            "id": rid,
            "prompt": prompt,
            "response": response,
            "status": status,
            "error": error,
        }
        save(args.output, results, order)  # зберігаємо після кожного рядка
        print(f"[{rid}] {status}" + (f": {error}" if error else ""))
        if not args.dry_run and args.delay > 0:
            time.sleep(args.delay)

    save(args.output, results, order)
    print(f"Готово: {len(rows) - failed} з {len(rows)} успішно, помилок: {failed}")
    return 1 if failed else 0


def main():
    p = argparse.ArgumentParser(description="Пакетний прогін промптів із CSV")
    p.add_argument("input", type=Path, help="CSV із колонками id,prompt")
    p.add_argument("-o", "--output", type=Path, default=Path("results.csv"))
    p.add_argument("--dry-run", action="store_true", help="без реальних запитів")
    p.add_argument("--delay", type=float, default=1.0, help="пауза між запитами, с")
    p.add_argument("--retries", type=int, default=2, help="повторні спроби")
    sys.exit(run(p.parse_args()))


if __name__ == "__main__":
    main()
